% clear all
% mex cec14_func.cpp -DWINDOWS
% func_num=1;
function [f_mean,f_std,f_best,f_worst]=main_NMRA
D=30;
Xmin=-100;
Xmax=100;
pop_size=50;
iter_max=30000;
runs=1;
fhd=str2func('cec17_func');
for i=1:30
    func_num=i;
%     for j=1:runs
%         i,j,
%         [gbest,gbestval,FES]= PSO_func(fhd,D,pop_size,iter_max,Xmin,Xmax,func_num);
%         xbest(j,:)=gbest;
%         fbest(i,j)=gbestval;
%         fbest(i,j)
%     end
%     f_mean(i)=mean(fbest(i,:));
    
    for j=1:runs
        i,j,
    [NMRAbest,NMRAfmin,bb]=NMRA_chebyshevmap(fhd,D,pop_size,iter_max,Xmin,Xmax,func_num);
    Xbest(j,:)=NMRAbest;
    fbest(i,j)=NMRAfmin;
    fbest(i,j)
%     eNMRA(i,j)=bb;
    end
    f_mean(i)=mean(fbest(i,:));
    f_std(i)=std(fbest(i,:));
    f_best(i)=min(fbest(i,:));
    f_worst(i)=max(fbest(i,:));
    
%     for j=1:runs
%      [fpabest,fpafmin,bb]=fpa_demo(fhd,D,pop_size,iter_max,Xmin,Xmax,func_num);
%         fpabest(i,:)=fpabest;
%     rFPA(i,:)=fpafmin;
%     efpa(i,:)=bb;
%     disp('FPA runs completed');
%     end
    
end




% for i=1:30
% eval(['load input_data/shift_data_' num2str(i) '.txt']);
% eval(['O=shift_data_' num2str(i) '(1:10);']);
% f(i)=cec14_func(O',i);i,f(i)
% end