function [bestnest,fmin,error_val,bb]=IGDN(Fun,D,N_iter,Lb,Ub,func_no)
% cv1(Ub,Lb,Dim,Fun,n,N_iter)
global initial_flag
rand('seed', sum(100 * clock));
% n=20;
% pa=0.75;
nd=D;
n=10*nd;
min_pop=20;
% Lb=Lb*ones(1,nd);
% Ub=Ub*ones(1,nd);
% disp('Version 1.0 CS');
val_2_reach=10^(-8);
optimum=func_no * 100.00;
threshold=0.01;
for i=1:n,
    nest(i,:)=Lb+(Ub-Lb).*rand(size(Lb));
end
iter=1;
fitness=10^10*ones(n,1);
[fmin,bestnest,nest,fitness]=get_best_nest(nest,nest,fitness,Fun,func_no,n);
% nest
% pause
for t=1:N_iter
    d=rand;
    a=2;
    %     b=0.1;
    c=2;
    %     a=pmax/pmin;
    %     b(i)=((i/200)^pmin-1)*(exp(-1*(i/200)^pmin));
    %  p(i,:)=ramp(i)+a*(sin((pi/N)*i))*exp(-0.5*(((i-1)/d)^2));
    % q(i,:)=rand+a*tanh((i-1)/d)*sin((pi/N)*i);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    pa=rand();

    if t<N_iter/4  %NMRA
        new_nest=get_cuckoos(nest,bestnest,Lb,Ub,N_iter,n);
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
        new_nest=empty_nests(best,nest,Lb,Ub,pa,n) ;
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
    elseif iter>N_iter/4 && iter<2*N_iter/4 %INFO
        new_nest=get_INFO(nest,bestnest,Lb,Ub,n);
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
        new_nest=new_empty_nests(nest,Lb,Ub,pa,N_iter,iter,n);
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
    elseif iter>2*N_iter/4 && iter<3*N_iter/4 %GOA
        new_nest=get_GOA(nest,bestnest,Lb,Ub,n,iter);
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
        new_nest=new_empty_nests(nest,Lb,Ub,pa,N_iter,iter,n);
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
    else % DOMA
        new_nest=get_DMOA(nest,bestnest,Lb,Ub,n);
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
        new_nest=new_empty_nests(nest,Lb,Ub,pa,N_iter,iter,n);
        [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,Fun,func_no,n);
    end
    bb(iter)=fmin;
    %     bsf_fit_var=fmin;
    %      error_val = bsf_fit_var - optimum;
    %         if error_val < val_2_reach
    %             error_val = 0;
    %         end
    %         cc(iter)=error_val;
    iter=iter+1;
    %     pa=pa-(0.9-0.4)/N_iter ;

    initial_flag=1;
    %      if t>N_iter/4
    %         n=n/4;
    %     end
    aa=n;

    nest=nest(1:n,:);
    fitness=fitness(1:n,:);
    bb=size(nest);
    cc=size(fitness);
end
bsf_fit_var=fmin;
error_val = bsf_fit_var - optimum;
if error_val < val_2_reach
    error_val = 0;
end
%% --------------- All subfunctions ------------------
%% Find the current best nest
%% Find the current best nest
function [fmin,best,nest,fitness]=get_best_nest(nest,newnest,fitness,Fun,func_no,n)
% Evaluating all new solutions
% newnest
% e=feval(Fun,newnest',func_no)
% pause
for j=1:size(nest,1),
%for j=1:n
    %     nest(j,:);
    fnew=feval(Fun,newnest(j,:)',func_no)';
    %     pause
    %     fnew=Fun(newnest(j,:));
    if fnew<=fitness(j),

        fitness(j)=fnew;

        nest(j,:)=newnest(j,:);
    end
end
% pnest=sort
% [nest]=1:n
% Find the current best
% nest
% fitness=fitness';
% pause
[fmin,K]=min(fitness);
best=nest(K,:);
%% Breeder Phase
function nest=get_cuckoos(nest,best,Lb,Ub,N_iter,n)
% n=size(nest,1);
beta=1;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
% maxiter=500;
for j=1:n,
    a=2-j*((2)/N_iter); % a decreases linearly fron 2 to 0
    s=nest(j,:);
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);
    r1=rand(); % r1 is a random number in [0,1]
    r2=rand(); % r2 is a random number in [0,1]
    A1=2*a*r1-a; % Equation (3.3)
    C1=2*r2;% Equation (3.4)
    D_alpha=abs(C1*best-nest(j,:)); % Equation (3.5)-part 1
    X1=best-A1*D_alpha;% Equation (3.6)-part 1
    r1=rand();
    r2=rand();
    A2=2*a*r1-a; % Equation (3.3)
    C2=2*r2; % Equation (3.4)
    D_beta=abs(C2*best-nest(j,:)); % Equation (3.5)-part 2
    X2=best-A2*D_beta; % Equation (3.6)-part 2
    r1=rand();
    r2=rand();
    A3=2*a*r1-a; % Equation (3.3)
    C3=2*r2; % Equation (3.4)
    D_delta=abs(C3*best-nest(j,:)); % Equation (3.5)-part 3
    X3=best-A3*D_delta; % Equation (3.5)-part 3
    nest(j,:)=(X1+X2+X3)/3;% Equation (3.7)        %     pause
    s=nest(j,:);
    stepsize=0.01*step.*(s-best);
    s=s+stepsize.*randn(size(s));

    %     nest
    %     pause
    % Apply simple bounds/limits
    nest(j,:)=simplebounds(s,Lb,Ub,n);
end


%% Replace some nests by constructing new solutions/nests
function new_nest=empty_nests(best,nest,Lb,Ub,pa,n)

np=size(nest,1);
% n
% pause
% xxx=size(nest,1)
% pause
% for i=((n/2)+1):n
for i=1:np
    K=rand(size(nest))>pa;
    stepsize=rand*(nest(randperm(n),:)-nest(randperm(n),:));
    new_nest=nest(1:n,:)+stepsize.*K;
end
for j=1:n
    s=new_nest(j,:);
    new_nest(j,:)=simplebounds(s,Lb,Ub,n);
end
function new_nest=new_empty_nests(nest,Lb,Ub,pa,N_iter,iter,n)
n=size(nest,1);
K=rand(size(nest))>pa;
% pause
p1 = 0.5;
p2 = 0.5;
if(p1>p2)
    sf = 0.5.*( sin(2.*pi.*rand.*iter+pi) .* ((N_iter-iter)/iter) + 1 );
else
    sf = 0.5 *( sin(2*pi.*rand.* N_iter) .* (iter/N_iter) + 1 );
end
stepsize=sf*(nest(randperm(n),:)-nest(randperm(n),:));
new_nest=nest+stepsize.*K;
for j=1:size(new_nest,1)
    s=new_nest(j,:);
    new_nest(j,:)=simplebounds(s,Lb,Ub,n);
end
function nest=get_different_cuckoos(nest,best,Lb,Ub,n)
%  n=size(nest,1)
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
% zzzz=size(nest)
for j=1:n,
    %     n
    s=nest(j,:);
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);
    stepsize=0.01*step.*(s-best);
    %       bbes=normpdf(((s+best)/2),(abs(s-best)));
    %       pause
    s=s+stepsize.*randn(size(s));
    %         s=rand*bbb+((1-rand)*bbes);
    %         pause
    nest(j,:)=simplebounds(s,Lb,Ub,n);

end

function nest=get_INFO(nest,best,Lb,Ub,n)
%  n=size(nest,1)
P = rand();
R = rand();
CF = rand();
% if rand<0.5
%    Sp(i,:)=P.*NMRsolution(ab(1),:)-P.*NMRsolution(ab(2),:);
%  mu (z1 -z2) It increases diversity in the algorithm
%    S(i,:)=NMRsolution(i,:)+P*R*Sp(i,:);
% else
%    Sp(i,:)=lambda*lambda*NMRsolution(ab(1),:)-NMRsolution(ab(2),:);
%    S(i,:)=NMRsolution(i,:)+P*CF*Sp(i,:);
% end
for i=1:n
    if rand<0.5
        stepsize=P*(nest(randperm(n),:)-P*nest(randperm(n),:));
        new_nest=nest(1:n,:)+stepsize.*P*CF;
    else
        stepsize=lambda*(nest(randperm(n),:)-nest(randperm(n),:));
        new_nest=nest(1:n,:)+stepsize.*P*R;
    end
end
for j=1:n
    s=new_nest(j,:);
    new_nest(j,:)=simplebounds(s,Lb,Ub,n);
end

function nest=get_GOA(nest,best,Lb,Ub,n,iter)
RB=randn();          %Brownian random number vector
R=rand();
CF = rand();
L = rand();
P = rand();
if mod(iter,2)==0
    mu=-1;
else
    mu=1;
end

for i=1:n
    if i>size(nest,1)/2
        stepsize=RB*(L.*best-nest(randperm(n),:));
        new_nest=best+P*mu*CF.*stepsize(i,:);
    else
        stepsize=L.*(best-L.*nest(randperm(n),:));
        new_nest=nest(randperm(n),:)+P*mu*R.*stepsize;
    end
end
for j=1:n
    s=new_nest(j,:);
    new_nest(j,:)=simplebounds(s,Lb,Ub,n);
end

function nest=get_DMOA(nest,best,Lb,Ub,n)
%  n=size(nest,1)
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
% zzzz=size(nest)
for j=1:n,
    %     n
    s=nest(j,:);
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);
    stepsize=0.01*step.*(s-best);
    %       bbes=normpdf(((s+best)/2),(abs(s-best)));
    %       pause
    s=s+stepsize.*randn(size(s));
    %         s=rand*bbb+((1-rand)*bbes);
    %         pause
    nest(j,:)=simplebounds(s,Lb,Ub,n);

end
% pause
% j
% n
% pp=size(nest)
% nest
% n
% ppp=size(s)
% xxxxx=size(nest)
% Application of simple constraints
function s=simplebounds(s,Lb,Ub,n)
% Apply the lower bound
ns_tmp=s;
I=ns_tmp<Lb;
ns_tmp(I)=Lb(I);
spo=size(s);
% Apply the upper bounds
J=ns_tmp>Ub;
ns_tmp(J)=Ub(J);
% Update this new move
s=ns_tmp;

%% You can replace the following by your own functions
% A d-dimensional objective function
% function z=rosenbrock(x)
% D= 30;
% sum1 = 0;
%         for i = 1:1:D
%             sum1 = sum1 + i*x(i)^4;
%         end
%         z = sum1 + rand();
